<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Forms Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the alert messages on the app
    | Feel free to change this however you need to do 
    |
    */

    'alert' => 'Oops! Something went wrong :',
];

