<?php

/***
 * Choose from: bootstrap, foundation, materialize
 * or create your own theme inside resources/views/pagination/
 * If you create a theme for a popular CSS framework
 * Please submit a pull request to: https://github.com/styde/blade-pagination
 * Or send me the template to admin@styde.net
 */
return array(
    'theme' => 'bootstrap'
);